self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "af206d4a8e2215ff4b9cf3e79a55c6f2",
    "url": "./index.html"
  },
  {
    "revision": "79764cca8ba33bd9e1cd",
    "url": "./static/js/2.07581672.chunk.js"
  },
  {
    "revision": "7c3e12da2bc1448f0cc28bbafdf52301",
    "url": "./static/js/2.07581672.chunk.js.LICENSE.txt"
  },
  {
    "revision": "9eef2a2f2438b35d591c",
    "url": "./static/js/main.7db5908d.chunk.js"
  },
  {
    "revision": "04c8140610772b57fb45",
    "url": "./static/js/runtime-main.bb71079c.js"
  }
]);